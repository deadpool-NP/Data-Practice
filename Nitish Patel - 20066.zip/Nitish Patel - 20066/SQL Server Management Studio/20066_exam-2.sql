--1
create table customer(
	C_id int primary key identity,
	C_FirstName varchar(50),
	C_MiddleName varchar(50),
	C_LastName varchar(50),
	C_Gender varchar(10),
	C_doj date,
	C_salary numeric(6),
	Department varchar(25)
)

--2
insert into customer values('Amit','Sumit','Patel','Male','2019/12/24',15000,'Banking'),
						   ('Saurabh','Jagdishbhai','Soni','Male','2015/07/14',7500,'Insurance'),
						   ('Mitesh','Niranjanbhai','Joshi','Male','2015/09/27',45500,'Banking'),
						   ('Aakansha','Bhogilal','Mehta','Female','2017/02/11',10500,'Services'),
						   ('Rehnuma','Ibrahim','Vora','Female','2018/02/12',5000,'Banking'),
						   ('Parin','Anilbhai','Patel','Male','2019/12/24',6500,'Banking'),
						   ('Kiran','Vitthabhai','Prajapati','Female','2019/12/24',15000,'Banking'),
						   ('Kiran','Tusharkumar','Shukla','Male','2013/09/09',35000,'Insurance'),
						   ('Jyoti','Sumit','Patel','Female','2013/04/05',34500,'Services'),
						   ('Sanskriti','Jivanlal','Joshi','Female','2012/12/12',28000,'Banking')

select * from customer

--3

select C_FirstName , C_LastName, C_salary from customer where Department = 'Insurance'

--4

select * from customer where C_MiddleName =(select C_MiddleName from customer group by C_MiddleName  having count(*) > 1) 

--5

--6
select avg(C_salary) from customer group by Department 

--7 
update customer
set Department = 'Sales'
where C_FirstName = 'Jyoti'

--8

--9

alter table customer
add  C_contact numeric(10)

--10

update customer
set C_contact ='8511742910'
where Department = 'Banking'