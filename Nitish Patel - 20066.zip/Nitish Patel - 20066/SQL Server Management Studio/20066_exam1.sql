--1
create table students(
	s_id int  ,
	s_name varchar(50),
	s_subject varchar(30),
	s_mark numeric(3)
)

select * from students

--2
insert into students values(1,'nitish','math',99),(1,'nitish','science',46),(1,'nitish','english',40),(2,'shubham','math',89),(2,'shubham','science',56),(2,'shubham','english',33),(3,'rajan','math',56),(3,'rajan','science',91),(3,'rajan','english',31)

--3
select * from students where s_mark between 50 and 90 and s_subject = 'science'

--4

select *, iif(s_mark > 90  , 'A','F') as grade from students


alter table students
alter column s_mark varchar(50)
SELECT *,
CASE 
    WHEN s_mark > 90  THEN cast('A' as varchar)
	WHEN s_mark > 80  THEN cast('A-' as varchar)
	WHEN s_mark > 70  THEN cast('B' as varchar)
	WHEN s_mark > 60  THEN cast('B-' as varchar)
	WHEN s_mark > 50  THEN cast('C' as varchar)
	When s_mark >= 40  THEN cast('C-' as varchar)
	WHEN s_mark < 35  THEN cast('F' as varchar)
    Else s_mark
END as grade
FROM students

--5
declare @subject varchar(50)
set @subject = 'english'
declare @total numeric

select sum=s_mark from students where s_subject = 'english'
create proc sp_total()
@subject = 'english'
begin
	select sum=s_mark from students where s_subject = @subject
end
	
exec sp_total()
