create database kcs_demo
drop database kcs_demo
select * from sys.schemas

create table student(
id int,
name varchar(20)
)

select * from student

alter table student
add contant_no numeric(10)

insert into student values(101,'Nitish',8511742910)

insert into student(id,name) values(102,'Ram')

insert into student(contant_no,name,id) values(9228841192,'Shayam',103)

update student
set contact_no = 9928384576
where id = 102

alter table student
add contact_no numeric(10)

alter table student
drop column contact_no

insert into student values(104,'Rajan',7584930261)

delete from student where id = 104

create table emp
(
id int primary key identity(1,1),
name varchar(20) not null,
gender varchar(10), 
salary numeric(6) check(salary > 10000),
email varchar(100) unique
)

insert into emp values('Nitish','male',30000,'nitish@gmail.com')
insert into emp values('Ram','male',3000,'ram@gmail.com')
select * from INFORMATION_SCHEMA.TABLE_CONSTRAINTS

alter table emp 
drop constraint [CK__emp__salary__267ABA7A]

alter table emp
add constraint CK_emp_gender check(gender = 'male' or gender = 'female')

insert into emp values('Prem','male',3000,'prem@gmail.com')

select * from emp 
select * from [dbo].[emp Destination]

select salary from emp group by salary

SELECT * FROM emp  WHERE salary IN (
    SELECT salary FROM emp GROUP BY Salary HAVING COUNT(*) > 1
)

insert into emp values('Viren','male','19000','viren@gmail.com')

--SELECT TOP 5 * FROM emp ORDER BY salary DESC where salary  in ( select * from emp order by desc limit 1)

select top 1 salary from (select  top 5 * from emp  ORDER BY salary DESC  ) AS a group by  a.salary  
select * from city
select * from state

select datepart(YYYY, soh.DueDate) as [Calendar Year], st.[Group] as [Sales Territory Group],
sum(soh.TotalDue) as [Sales Amount], pc.Name as Category
from Sales.SalesOrderHeader as soh
inner join Sales.SalesTerritory as st on soh.TerritoryID=st.TerritoryID
inner join Sales.SalesOrderDetail as sod on soh.SalesOrderID= sod.SalesOrderID
inner join Production.ProductCostHistory as pch on sod.ProductID=pch.ProductID
cross join Production.ProductCategory as pc
group by DATEPART(yyyy,soh.DueDate),st.[Group],pc.Name
order by [Calendar Year]

select datepart(YYYY, soh.DueDate) as [Calendar Year], st.[Group] as [Sales Territory Group],
cr.name as [Sales Territory Country],
cr.name as [Sales Territory Region],
sum(soh.TotalDue) as [Sales Amount]
from Sales.SalesOrderHeader as soh
inner join Sales.SalesTerritory as st on soh.TerritoryID=st.TerritoryID
inner join Sales.SalesOrderDetail as sod on soh.SalesOrderID= sod.SalesOrderID

	select datepart(YYYY, soh.DueDate) as [Calendar Year], st.[Group] as [Sales Territory Group],cr.name as [Sales Territory Country], cr.name as [sales territory region],
	sum(soh.TotalDue) as [Sales Amount]
	from Sales.SalesOrderHeader as soh
	inner join Sales.SalesTerritory as st on soh.TerritoryID=st.TerritoryID
	inner join Sales.SalesOrderDetail as sod on soh.SalesOrderID= sod.SalesOrderID
	inner join Production.ProductCostHistory as pch on sod.ProductID=pch.ProductID
	inner join person.countryregion as cr on st.CountryRegionCode=cr.CountryRegionCode
	group by DATEPART(yyyy,soh.DueDate),st.[Group],cr.Name
	order by [Calendar Year]